
import React, { useState, useRef, useEffect } from 'react';
import { Message, View, User, THEMES } from '../types';

interface PrivateSpaceProps {
  messages: Message[];
  user: User;
  onSendMessage: (msg: Omit<Message, 'id' | 'timestamp' | 'status'>) => void;
  onDeleteMessage: (id: string) => void;
  onMarkImageAsOpened: (id: string) => void;
  onClearAll: () => void;
  onImportData: (data: string) => void;
  onLock: () => void;
  onUpdateUser: (updates: Partial<User>) => void;
}

const PrivateSpace: React.FC<PrivateSpaceProps> = ({ 
  messages, user, onSendMessage, onDeleteMessage, onMarkImageAsOpened, onClearAll, onImportData, onLock, onUpdateUser 
}) => {
  const [view, setView] = useState<View>(View.Chat);
  const [inputText, setInputText] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [syncCode, setSyncCode] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const partnerAvatarInputRef = useRef<HTMLInputElement>(null);
  const userAvatarInputRef = useRef<HTMLInputElement>(null);

  const activeTheme = user.theme || 'guts';
  const themeData = THEMES[activeTheme as keyof typeof THEMES] || THEMES.guts;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, view]);

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage({ sender: 'me', text: inputText, type: 'text' });
      setInputText('');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isPartner: boolean = false, isUser: boolean = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const r = new FileReader();
      r.onloadend = () => {
        const base64 = r.result as string;
        if (isPartner) onUpdateUser({ partnerAvatar: base64 });
        else if (isUser) onUpdateUser({ avatar: base64 });
        else {
          const isTemp = window.confirm("¿Hacer este mensaje temporal (ver una vez)?");
          onSendMessage({ sender: 'me', text: '', type: 'image', imageUrl: base64, isSelfDestruct: isTemp, isOpened: false });
        }
      };
      r.readAsDataURL(file);
    }
  };

  const generateSyncCode = () => {
    const code = btoa(JSON.stringify(messages));
    setSyncCode(code);
    navigator.clipboard.writeText(code);
    alert("¡Código de sincronización copiado! Envíaselo a tu pareja y que lo pegue en su configuración.");
  };

  const importSyncCode = () => {
    const input = prompt("Pega aquí el código que te envió tu pareja:");
    if (input) {
      try {
        const decoded = atob(input);
        onImportData(decoded);
        alert("¡Mensajes sincronizados con éxito!");
      } catch (e) {
        alert("Código no válido.");
      }
    }
  };

  return (
    <div className="flex flex-col h-screen fixed inset-0 z-[100] font-sans overflow-hidden transition-all duration-500" style={{ backgroundColor: themeData.bg, color: 'white' }}>
      {/* Header con Perfil de Pareja */}
      <header className="px-5 py-4 flex justify-between items-center shadow-2xl z-20 border-b border-white/5" style={{ backgroundColor: themeData.header }}>
        <div className="flex items-center space-x-4 cursor-pointer" onClick={() => setShowSettings(true)}>
          <div className="relative">
            <div className="w-12 h-12 rounded-full border-2 border-white/20 overflow-hidden bg-gray-800 flex items-center justify-center">
              {user.partnerAvatar ? (
                <img src={user.partnerAvatar} className="w-full h-full object-cover" />
              ) : (
                <span className="text-xl opacity-30">❤</span>
              )}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-black bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
          </div>
          <div>
            <h2 className="text-sm font-black tracking-tight flex items-center space-x-2">
              <span>{user.partnerName || 'Mi Pareja'}</span>
              {user.partyId && <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full font-mono text-purple-300">#{user.partyId}</span>}
            </h2>
            <p className="text-[8px] uppercase font-black tracking-[0.2em] opacity-40">En línea ahora</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button onClick={() => setShowThemeSelector(true)} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all text-xl">🎨</button>
          <button onClick={() => setShowSettings(true)} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all text-xl">⚙️</button>
          <button onClick={onLock} className="p-2.5 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-all ml-2 text-xl">🚪</button>
        </div>
      </header>

      {/* Navegación Tabs */}
      <div className="flex bg-black/40 backdrop-blur-md border-b border-white/5 z-10">
        <button onClick={() => setView(View.Chat)} className={`flex-1 py-4 text-[10px] font-black uppercase tracking-[0.3em] transition-all border-b-2 ${view === View.Chat ? 'opacity-100' : 'opacity-20 border-transparent'}`} style={{ color: view === View.Chat ? themeData.primary : 'white', borderColor: view === View.Chat ? themeData.primary : 'transparent' }}>Chat</button>
        <button onClick={() => setView(View.Gallery)} className={`flex-1 py-4 text-[10px] font-black uppercase tracking-[0.3em] transition-all border-b-2 ${view === View.Gallery ? 'opacity-100' : 'opacity-20 border-transparent'}`} style={{ color: view === View.Gallery ? themeData.primary : 'white', borderColor: view === View.Gallery ? themeData.primary : 'transparent' }}>Bóveda</button>
      </div>

      {/* Área de Mensajes */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {view === View.Chat ? (
          <div ref={scrollRef} className="space-y-6 pb-20">
            {messages.length === 0 && (
              <div className="text-center py-20 opacity-10 animate-pulse">
                <span className="text-8xl block mb-4">✨</span>
                <p className="text-xs font-black uppercase tracking-[0.5em]">Toca para empezar vuestro diario</p>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'} animate-fade`}>
                <div 
                  className={`max-w-[85%] px-5 py-4 rounded-[1.8rem] shadow-2xl relative group ${m.sender === 'me' ? 'rounded-tr-none' : 'rounded-tl-none border border-white/10'}`}
                  style={{ backgroundColor: m.sender === 'me' ? themeData.bubbleMe : themeData.header }}
                  onDoubleClick={() => { if(window.confirm("¿Borrar mensaje?")) onDeleteMessage(m.id) }}
                >
                  {m.type === 'image' ? (
                    <div className="relative min-w-[180px]">
                      {m.isSelfDestruct && !m.isOpened ? (
                        <button 
                          onClick={() => { setSelectedImage(m.imageUrl || null); onMarkImageAsOpened(m.id); }}
                          className="flex flex-col items-center justify-center p-10 bg-black/60 rounded-2xl border-2 border-dashed border-white/20 w-full active:scale-95 transition-transform"
                        >
                          <span className="text-4xl mb-3">🔥</span>
                          <span className="text-[9px] font-black uppercase tracking-widest text-white/50">Foto Temporal</span>
                        </button>
                      ) : m.isSelfDestruct && m.isOpened ? (
                        <div className="py-6 text-[10px] font-black opacity-20 uppercase italic text-center tracking-[0.3em]">Imagen Destruida</div>
                      ) : (
                        <img src={m.imageUrl} onClick={() => setSelectedImage(m.imageUrl || null)} className="max-h-[350px] w-full object-cover rounded-2xl cursor-zoom-in" />
                      )}
                    </div>
                  ) : (
                    <p className="text-[16px] leading-relaxed break-words font-medium">{m.text}</p>
                  )}
                  <div className="flex items-center justify-end mt-2 opacity-40 space-x-1.5">
                    <span className="text-[9px] font-bold">{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {m.sender === 'me' && <span className="text-[11px]">{m.status === 'read' ? '✓✓' : '✓'}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2 pb-10">
            {messages.filter(m => m.type === 'image' && !m.isSelfDestruct).map(img => (
              <div key={img.id} className="aspect-square relative overflow-hidden rounded-xl bg-white/5 border border-white/5 active:scale-90 transition-transform">
                <img src={img.imageUrl} onClick={() => setSelectedImage(img.imageUrl || null)} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Input */}
      {view === View.Chat && (
        <footer className="p-4 bg-black/80 backdrop-blur-2xl border-t border-white/5 flex items-center space-x-3 pb-8">
          <button onClick={() => fileInputRef.current?.click()} className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl active:scale-90 transition-transform flex-shrink-0" style={{ backgroundColor: themeData.primary }}>📷</button>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e)} />
          
          <div className="flex-1 bg-white/5 rounded-2xl px-5 py-4 border border-white/10 shadow-inner">
            <input 
              type="text" 
              placeholder="Habla con tu novia..." 
              className="w-full bg-transparent text-sm outline-none placeholder:text-white/20"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
          </div>

          <button onClick={handleSend} disabled={!inputText.trim()} className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl active:scale-90 transition-transform disabled:opacity-20 flex-shrink-0" style={{ backgroundColor: themeData.primary }}>🏹</button>
        </footer>
      )}

      {/* MODAL AJUSTES */}
      {showSettings && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-3xl p-6 flex items-center justify-center animate-fade">
          <div className="w-full max-w-md bg-[#1a1a1a] rounded-[3.5rem] p-8 border border-white/10 space-y-8 overflow-y-auto max-h-[90vh] shadow-[0_0_100px_rgba(0,0,0,1)]">
            <div className="text-center space-y-2">
              <h3 className="font-['Dancing+Script'] text-6xl text-white">settings</h3>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] opacity-40">Personalización del rincón</p>
            </div>

            {/* Perfil Tuya */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-purple-400 border-b border-purple-400/20 pb-2">Tu Identidad</h4>
              <div className="flex items-center space-x-4 bg-white/5 p-4 rounded-3xl">
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/10 bg-black/40 flex items-center justify-center cursor-pointer" onClick={() => userAvatarInputRef.current?.click()}>
                   {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <span className="text-2xl">👤</span>}
                </div>
                <input type="file" ref={userAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, false, true)} />
                <div className="flex-1">
                  <input 
                    type="text" 
                    className="bg-transparent border-b border-white/10 w-full font-bold text-sm py-1 outline-none focus:border-purple-500"
                    placeholder="Tu nombre"
                    value={user.name}
                    onChange={(e) => onUpdateUser({ name: e.target.value })}
                  />
                  <p className="text-[9px] opacity-40 mt-1">NIP: {user.nip}</p>
                </div>
              </div>
            </section>

            {/* Perfil Pareja */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-green-400 border-b border-green-400/20 pb-2">Tu Pareja (Modo Party)</h4>
              <div className="bg-white/5 p-6 rounded-[2.5rem] space-y-6">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase opacity-40 block">Código Party ID</label>
                  <input 
                    type="text" 
                    className="w-full bg-black/40 rounded-xl px-4 py-3 text-sm font-mono outline-none border border-white/5 focus:border-green-500"
                    placeholder="Ej: NUESTRO2024"
                    value={user.partyId || ''}
                    onChange={(e) => onUpdateUser({ partyId: e.target.value.toUpperCase() })}
                  />
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-white/10 bg-black/40 flex items-center justify-center cursor-pointer" onClick={() => partnerAvatarInputRef.current?.click()}>
                    {user.partnerAvatar ? <img src={user.partnerAvatar} className="w-full h-full object-cover" /> : <span className="text-2xl">❤</span>}
                  </div>
                  <input type="file" ref={partnerAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, true)} />
                  <input 
                    type="text" 
                    className="flex-1 bg-black/40 rounded-xl px-4 py-3 text-sm font-bold outline-none border border-white/5"
                    placeholder="Nombre de ella"
                    value={user.partnerName || ''}
                    onChange={(e) => onUpdateUser({ partnerName: e.target.value })}
                  />
                </div>
              </div>
            </section>

            {/* Sincronización Manual */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-blue-400 border-b border-blue-400/20 pb-2">Sincronización (Multi-dispositivo)</h4>
              <div className="grid grid-cols-1 gap-3">
                <button onClick={generateSyncCode} className="w-full bg-blue-600/20 text-blue-400 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-blue-600/30 active:scale-95 transition-all">Generar & Copiar Código</button>
                <button onClick={importSyncCode} className="w-full bg-green-600/20 text-green-400 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-green-600/30 active:scale-95 transition-all">Importar Código Recibido</button>
                <p className="text-[8px] text-center opacity-30 px-4">Usa esto para "enviar" los mensajes de un teléfono a otro copiando el código por WhatsApp.</p>
              </div>
            </section>

            <section className="grid grid-cols-2 gap-3 pt-4">
              <button onClick={() => { if(window.confirm("¿Borrar todo el historial?")) onClearAll(); }} className="bg-red-500/10 text-red-500 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest">Resetear Chat</button>
              <button onClick={() => setShowSettings(false)} className="bg-white/5 text-white/50 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest">Cerrar</button>
            </section>
          </div>
        </div>
      )}

      {/* Selector Temas */}
      {showThemeSelector && (
        <div className="fixed inset-0 z-[400] bg-black/98 backdrop-blur-3xl flex items-center justify-center p-8 animate-fade">
          <div className="w-full max-w-sm bg-gray-900/40 rounded-[4rem] p-10 border border-white/10 space-y-10 shadow-2xl">
            <h3 className="text-center font-['Dancing+Script'] text-6xl text-white">moods</h3>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(THEMES).map(([key, t]) => (
                <button 
                  key={key} 
                  onClick={() => { onUpdateUser({ theme: key }); setShowThemeSelector(false); }}
                  className={`group relative p-6 rounded-[2.5rem] border-4 transition-all overflow-hidden active:scale-95 ${activeTheme === key ? 'border-white' : 'border-transparent opacity-40'}`}
                  style={{ backgroundColor: t.bg }}
                >
                  <div className="w-8 h-8 rounded-full mb-3 mx-auto shadow-lg" style={{ backgroundColor: t.primary }}></div>
                  <span className="text-[10px] font-black uppercase tracking-widest block text-center leading-tight">{t.name}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowThemeSelector(false)} className="w-full text-[10px] font-black uppercase opacity-20 tracking-[0.5em] py-4">Volver</button>
          </div>
        </div>
      )}

      {/* Visor Imagen */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/98 z-[500] flex items-center justify-center p-4 backdrop-blur-3xl animate-fade" onClick={() => setSelectedImage(null)}>
          <img src={selectedImage} className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.1)] animate-in zoom-in duration-300" />
          <div className="absolute top-10 right-10 text-white/40 text-6xl font-light cursor-pointer">×</div>
        </div>
      )}
    </div>
  );
};

export default PrivateSpace;
