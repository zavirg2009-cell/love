
import React, { useState } from 'react';

interface DecoyViewProps {
  onUnlock: (pin: string) => void;
}

const DecoyView: React.FC<DecoyViewProps> = ({ onUnlock }) => {
  const [comment, setComment] = useState('');
  const [isPosted, setIsPosted] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'merch' | 'music'>('merch');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // El acceso secreto ahora es simplemente un comentario
    if (comment.trim() === '7112024') {
      onUnlock('7112024');
      return;
    }
    
    if (comment.trim().length < 5) return;

    setIsPosted(true);
    setTimeout(() => {
      setIsPosted(false);
      setComment('');
      alert("¡Gracias por tu comentario! Aparecerá después de ser moderado. 💜");
    }, 1200);
  };

  const merchItems = [
    { name: "drivers license 5 year anniversary crewneck", img: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop", price: "$65.00", link: "https://store.oliviarodrigo.com/products/drivers-license-5-year-anniversary-crewneck" },
    { name: "i still fucking love you locket", img: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop", price: "$40.00", link: "https://store.oliviarodrigo.com/products/i-still-fucking-love-you-locket" },
    { name: "drivers license 5 year anniversary t-shirt", img: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=600&auto=format&fit=crop", price: "$35.00", link: "https://store.oliviarodrigo.com/products/drivers-license-5-year-anniversary-t-shirt" },
    { name: "U+ME 4EVR charm", img: "https://images.unsplash.com/photo-1611085211827-73d6019b0992?q=80&w=600&auto=format&fit=crop", price: "$15.00", link: "https://store.oliviarodrigo.com/" }
  ];

  return (
    <div className="min-h-screen bg-[#c9b7e0] font-sans text-gray-800 relative overflow-x-hidden selection:bg-purple-400">
      {/* Textura de papel de cuaderno */}
      <div className="fixed inset-0 pointer-events-none opacity-20 bg-[url('https://www.transparenttextures.com/patterns/notebook.png')]"></div>

      {/* Header oficial replicado */}
      <nav className="relative z-10 px-6 py-8 flex flex-col items-center space-y-8 md:flex-row md:justify-between md:space-y-0 max-w-7xl mx-auto">
        <div className="w-48 cursor-pointer hover:scale-105 transition-transform" onClick={() => window.location.reload()}>
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Olivia_Rodrigo_logo.svg/1200px-Olivia_Rodrigo_logo.svg.png" className="w-full h-auto brightness-0" alt="Olivia Rodrigo Logo" />
        </div>
        
        <div className="flex items-center space-x-6 md:space-x-10 text-[11px] uppercase font-bold tracking-widest text-[#4a336e]">
          <a href="https://store.oliviarodrigo.com" target="_blank" rel="noreferrer" className="hover:line-through hover:text-black transition-all">shop</a>
          <a href="https://oliviarodrigo.lnk.to/listen" target="_blank" rel="noreferrer" className="hover:line-through hover:text-black transition-all">listen</a>
          <a href="https://www.oliviarodrigo.com/tour" target="_blank" rel="noreferrer" className="hover:line-through hover:text-black transition-all">tour</a>
          <div className="hidden md:block group relative cursor-pointer">
            <span className="hover:line-through">more</span>
          </div>
          <a href="https://www.oliviarodrigo.com/#signup" target="_blank" rel="noreferrer" className="bg-black text-white px-5 py-2 rounded-md hover:bg-purple-900 transition-colors">sign up</a>
        </div>

        <div className="flex items-center space-x-5 opacity-60">
          <svg className="w-5 h-5 cursor-pointer hover:text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <svg className="w-5 h-5 cursor-pointer hover:text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
          <a href="https://store.oliviarodrigo.com/cart" target="_blank" rel="noreferrer">
            <svg className="w-5 h-5 cursor-pointer hover:text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          </a>
        </div>
      </nav>

      <main className="relative z-10 max-w-6xl mx-auto px-6 py-12">
        {/* Selector de categoría interactivo */}
        <div className="flex justify-center space-x-12 mb-16">
          <button 
            onClick={() => setActiveCategory('merch')}
            className={`text-3xl font-['Dancing+Script'] font-black border-2 border-dashed px-10 py-3 rounded-full transform transition-all hover:scale-105 active:scale-95 ${activeCategory === 'merch' ? 'border-black -rotate-2 bg-white' : 'border-transparent opacity-40 -rotate-1'}`}
          >
            merch
          </button>
          <button 
            onClick={() => setActiveCategory('music')}
            className={`text-3xl font-['Dancing+Script'] font-black transform transition-all hover:scale-105 active:scale-95 ${activeCategory === 'music' ? 'text-purple-950 underline underline-offset-8 rotate-2' : 'text-purple-800 opacity-40 rotate-1'}`}
          >
            music
          </button>
        </div>

        {/* Grid de Merch */}
        {activeCategory === 'merch' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {merchItems.map((item, idx) => (
              <a href={item.link} target="_blank" rel="noreferrer" key={idx} className="group flex flex-col items-center text-center">
                <div className="aspect-[3/4] w-full bg-[#d7cce6] p-6 relative overflow-hidden transition-all duration-500 group-hover:bg-[#beb2cf]">
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] rounded-full border border-gray-200 z-10">
                    pre-order
                  </div>
                  
                  {/* Doodles decorativos */}
                  {idx === 0 && <span className="absolute top-12 right-6 text-4xl opacity-20 group-hover:opacity-40 transition-opacity">🦋</span>}
                  {idx === 1 && <span className="absolute bottom-6 right-6 text-5xl opacity-10 group-hover:opacity-30 transition-opacity">🌀</span>}
                  {idx === 3 && <span className="absolute bottom-10 left-4 text-4xl opacity-20 group-hover:rotate-12 transition-all">💘</span>}

                  <img src={item.img} className="w-full h-full object-cover mix-blend-multiply group-hover:scale-110 transition-transform duration-700" alt={item.name} />
                </div>
                <div className="mt-8 space-y-2">
                  <h3 className="text-[11px] font-black uppercase tracking-tighter leading-tight max-w-[160px] group-hover:underline">{item.name}</h3>
                  <p className="text-xs opacity-50 font-bold">{item.price}</p>
                </div>
              </a>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="bg-white/30 p-8 rounded-[2rem] border-2 border-dashed border-purple-400 text-center space-y-6">
              <h4 className="text-4xl font-['Dancing+Script'] font-black">GUTS (Spilled)</h4>
              <img src="https://upload.wikimedia.org/wikipedia/en/0/03/Olivia_Rodrigo_-_Guts.png" className="w-64 h-64 mx-auto rounded-lg shadow-xl" alt="GUTS Album" />
              <button className="bg-purple-900 text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:bg-black transition-colors">Listen Now</button>
            </div>
            <div className="bg-white/30 p-8 rounded-[2rem] border-2 border-dashed border-purple-400 text-center space-y-6">
              <h4 className="text-4xl font-['Dancing+Script'] font-black">SOUR</h4>
              <img src="https://upload.wikimedia.org/wikipedia/en/b/b2/Olivia_Rodrigo_-_Sour.png" className="w-64 h-64 mx-auto rounded-lg shadow-xl" alt="SOUR Album" />
              <button className="bg-purple-900 text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:bg-black transition-colors">Listen Now</button>
            </div>
          </div>
        )}

        {/* Sección de Video "Fan Pick" */}
        <div className="mt-32 mb-20 text-center">
           <div className="inline-block mb-6 opacity-30">
              <span className="text-6xl">✨</span>
           </div>
           <h4 className="font-['Dancing+Script'] text-6xl mb-12 transform -rotate-1">livies community videos</h4>
           <div className="aspect-video max-w-4xl mx-auto rounded-3xl overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)] border-[12px] border-white relative group">
              <iframe 
                className="w-full h-full" 
                src="https://www.youtube.com/embed/gNi_6U5Pm_o?rel=0&modestbranding=1" 
                title="Olivia Rodrigo - vampire (Official Video)" 
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
              ></iframe>
           </div>
        </div>

        {/* Muro de Comentarios de Fans (Acceso Secreto) */}
        <section className="mt-32 border-t-2 border-dashed border-purple-900/20 pt-24 pb-32">
          <div className="max-w-2xl mx-auto bg-white/50 p-10 md:p-16 rounded-[4rem] backdrop-blur-md shadow-2xl border border-white/80 relative">
            {/* Doodles de esquina */}
            <div className="absolute -top-12 -left-8 text-7xl opacity-30 select-none animate-bounce">💜</div>
            <div className="absolute -bottom-10 -right-6 text-7xl opacity-30 select-none rotate-12">🎸</div>

            <div className="text-center space-y-6 mb-12">
              <h5 className="font-['Dancing+Script'] text-6xl text-purple-950">fan wall</h5>
              <p className="text-[12px] uppercase font-black tracking-[0.4em] text-purple-900/60 leading-relaxed">
                Deja un mensaje para Olivia o comparte tu experiencia favorita del tour
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <textarea 
                  placeholder="Escribe tu comentario aquí..." 
                  className="w-full bg-white/90 border-4 border-purple-200 rounded-[2.5rem] px-10 py-8 text-sm font-bold placeholder:text-purple-200 outline-none focus:border-purple-500 transition-all min-h-[180px] resize-none shadow-inner"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  required
                ></textarea>
                <div className="absolute bottom-6 right-8 text-[10px] font-black uppercase opacity-20 tracking-widest">
                  Publicar como Fan Anónimo
                </div>
              </div>
              
              <button 
                type="submit"
                className="w-full bg-purple-950 text-white py-6 rounded-3xl font-black uppercase text-xs tracking-[0.5em] hover:bg-black transition-all shadow-xl active:scale-95 flex items-center justify-center space-x-3"
              >
                <span>{isPosted ? 'POSTING...' : 'ENVIAR COMENTARIO'}</span>
                {!isPosted && <span>➜</span>}
              </button>
            </form>

            <div className="mt-12 space-y-4 opacity-40">
              <div className="border-t border-purple-900/10 pt-6">
                <p className="text-[10px] font-black uppercase italic mb-1">Livie_4ever • hace 2 min</p>
                <p className="text-xs font-bold">¡Vampire es la mejor canción del año! No puedo esperar al próximo concierto. 💜🦋</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 py-16 text-center space-y-8 bg-black/5">
        <div className="flex flex-wrap justify-center gap-10 text-[10px] font-black uppercase tracking-[0.3em] opacity-50">
          <a href="https://www.oliviarodrigo.com/privacy-policy" target="_blank" rel="noreferrer" className="hover:text-black hover:underline">privacy policy</a>
          <a href="https://www.oliviarodrigo.com/terms-of-use" target="_blank" rel="noreferrer" className="hover:text-black hover:underline">terms of use</a>
          <a href="https://www.oliviarodrigo.com/contact" target="_blank" rel="noreferrer" className="hover:text-black hover:underline">contact</a>
        </div>
        <div className="flex justify-center space-x-8 opacity-40">
           <a href="https://www.instagram.com/oliviarodrigo/" target="_blank" rel="noreferrer" className="text-2xl hover:scale-125 transition-transform">📸</a>
           <a href="https://twitter.com/oliviarodrigo" target="_blank" rel="noreferrer" className="text-2xl hover:scale-125 transition-transform">🐦</a>
           <a href="https://www.tiktok.com/@livbedumb" target="_blank" rel="noreferrer" className="text-2xl hover:scale-125 transition-transform">🎵</a>
        </div>
        <p className="text-[9px] uppercase font-black tracking-[0.6em] opacity-20 pb-10">© 2024 Olivia Rodrigo Fan Project • No Official Site</p>
      </footer>
    </div>
  );
};

export default DecoyView;
