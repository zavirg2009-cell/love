
import React, { useState, useRef } from 'react';
import { User } from '../types';

interface AuthViewProps {
  onLogin: (nip: string) => void;
  onRegister: (user: User) => void;
  onBack: () => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLogin, onRegister, onBack }) => {
  const [mode, setMode] = useState<'CHOICE' | 'LOGIN' | 'REGISTER'>('CHOICE');
  const [nip, setNip] = useState('');
  const [name, setName] = useState('');
  const [avatar, setAvatar] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAvatar(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const submitRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (nip.length >= 4 && name.trim()) {
      onRegister({ nip, name, avatar: avatar || undefined });
    } else {
      alert("Completa todos los campos (NIP mín. 4 dígitos)");
    }
  };

  const submitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (nip.length >= 4) onLogin(nip);
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#0b141a] flex flex-col items-center justify-center p-6 text-white font-sans overflow-y-auto">
      <div className="w-full max-w-sm space-y-8 animate-in fade-in zoom-in duration-300 py-10">
        
        {mode === 'CHOICE' && (
          <div className="space-y-6 text-center">
            <div className="w-24 h-24 bg-gradient-to-tr from-purple-600 to-blue-500 rounded-[2rem] mx-auto flex items-center justify-center shadow-2xl animate-pulse">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-black italic tracking-tighter">SECURE LOVE</h2>
              <p className="text-[10px] text-gray-500 uppercase font-black tracking-[0.3em]">Cifrado de extremo a extremo</p>
            </div>
            <div className="grid gap-4 pt-6">
              <button onClick={() => setMode('LOGIN')} className="bg-[#202c33] border border-white/5 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-white/5 transition-all">Acceder</button>
              <button onClick={() => setMode('REGISTER')} className="bg-purple-600 py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-purple-600/30 hover:bg-purple-500 transition-all">Registrar Cuenta</button>
            </div>
          </div>
        )}

        {mode === 'REGISTER' && (
          <form onSubmit={submitRegister} className="space-y-6">
            <h3 className="text-center font-black uppercase text-xs tracking-widest text-purple-400">Nueva Cuenta</h3>
            
            <div className="flex flex-col items-center space-y-4">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-24 h-24 rounded-full bg-[#202c33] border-2 border-dashed border-purple-500/30 flex items-center justify-center overflow-hidden cursor-pointer hover:border-purple-500 transition-all"
              >
                {avatar ? <img src={avatar} className="w-full h-full object-cover" /> : <span className="text-xs text-gray-500 font-bold">Foto</span>}
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatar} />
            </div>

            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Nombre de usuario" 
                className="w-full bg-[#2a3942] rounded-xl px-6 py-4 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <input 
                type="password" 
                inputMode="numeric"
                placeholder="Crea tu NIP (4+ dígitos)" 
                className="w-full bg-[#2a3942] rounded-xl px-6 py-4 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                value={nip}
                onChange={(e) => setNip(e.target.value.replace(/\D/g, ''))}
              />
            </div>

            <button type="submit" className="w-full bg-purple-600 py-4 rounded-xl font-black uppercase text-xs tracking-widest">Crear mi espacio</button>
            <button type="button" onClick={() => setMode('CHOICE')} className="w-full text-gray-500 text-[10px] font-black uppercase tracking-widest">Cancelar</button>
          </form>
        )}

        {mode === 'LOGIN' && (
          <form onSubmit={submitLogin} className="space-y-6 text-center">
            <h3 className="font-black uppercase text-xs tracking-widest text-blue-400">Bienvenido de vuelta</h3>
            <input 
              type="password" 
              inputMode="numeric"
              placeholder="Ingresa tu NIP" 
              className="w-full bg-[#2a3942] rounded-2xl py-6 text-center text-4xl tracking-[0.5em] focus:ring-2 focus:ring-blue-500 outline-none font-mono"
              value={nip}
              onChange={(e) => setNip(e.target.value.replace(/\D/g, ''))}
              autoFocus
            />
            <button type="submit" className="w-full bg-blue-600 py-4 rounded-xl font-black uppercase text-xs tracking-widest">Entrar</button>
            <button type="button" onClick={() => setMode('CHOICE')} className="w-full text-gray-500 text-[10px] font-black uppercase tracking-widest">Volver</button>
          </form>
        )}

        <button onClick={onBack} className="w-full text-[9px] text-gray-600 uppercase font-black tracking-[0.4em] mt-10">Cerrar Sesión Segura</button>
      </div>
    </div>
  );
};

export default AuthView;
