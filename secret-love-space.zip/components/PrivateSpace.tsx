
import React, { useState, useRef, useEffect } from 'react';
import { Message, View, User, THEMES } from '../types';

interface PrivateSpaceProps {
  messages: Message[];
  user: User;
  onSendMessage: (msg: Omit<Message, 'id' | 'timestamp' | 'status'>) => void;
  onDeleteMessage: (id: string) => void;
  onMarkImageAsOpened: (id: string) => void;
  onClearAll: () => void;
  onImportData: (data: string) => void;
  onLock: () => void;
  onUpdateUser: (updates: Partial<User>) => void;
}

const PrivateSpace: React.FC<PrivateSpaceProps> = ({ 
  messages, user, onSendMessage, onDeleteMessage, onMarkImageAsOpened, onClearAll, onImportData, onLock, onUpdateUser 
}) => {
  const [view, setView] = useState<View>(View.Chat);
  const [inputText, setInputText] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const partnerAvatarInputRef = useRef<HTMLInputElement>(null);
  const userAvatarInputRef = useRef<HTMLInputElement>(null);

  const activeTheme = user.theme || 'guts';
  const themeData = THEMES[activeTheme as keyof typeof THEMES] || THEMES.guts;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, view]);

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage({ sender: 'me', text: inputText, type: 'text' });
      setInputText('');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isPartner: boolean = false, isUser: boolean = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const r = new FileReader();
      r.onloadend = () => {
        const base64 = r.result as string;
        if (isPartner) onUpdateUser({ partnerAvatar: base64 });
        else if (isUser) onUpdateUser({ avatar: base64 });
        else {
          const isTemp = window.confirm("¿Hacer este mensaje temporal?");
          onSendMessage({ sender: 'me', text: '', type: 'image', imageUrl: base64, isSelfDestruct: isTemp, isOpened: false });
        }
      };
      r.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col h-screen fixed inset-0 z-[100] font-sans overflow-hidden transition-all duration-500" style={{ backgroundColor: themeData.bg, color: 'white' }}>
      {/* Header Dinámico */}
      <header className="px-5 py-4 flex justify-between items-center shadow-xl z-20" style={{ backgroundColor: themeData.header }}>
        <div className="flex items-center space-x-4">
          <div className="relative cursor-pointer" onClick={() => setShowSettings(true)}>
            <div className="w-12 h-12 rounded-full border-2 border-white/20 overflow-hidden bg-gray-800">
              {user.partyId && user.partnerAvatar ? (
                <img src={user.partnerAvatar} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center font-black text-xl opacity-30">
                  {user.partyId ? (user.partnerName?.[0] || '❤') : '?'}
                </div>
              )}
            </div>
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-black ${user.partyId ? 'bg-green-500 shadow-[0_0_10px_#22c55e]' : 'bg-orange-500'}`}></div>
          </div>
          <div>
            <h2 className="text-sm font-black tracking-tight">
              {user.partyId ? (user.partnerName || 'Mi Pareja') : 'Espacio Privado'}
            </h2>
            <p className="text-[9px] uppercase font-black tracking-[0.2em] opacity-40">
              {user.partyId ? `PARTY ID: ${user.partyId}` : 'Sincronización OFF'}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button onClick={() => setShowThemeSelector(true)} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all">🎨</button>
          <button onClick={() => setShowSettings(true)} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all">⚙️</button>
          <button onClick={onLock} className="p-2.5 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-all ml-2">🚪</button>
        </div>
      </header>

      {/* Navegación de Pestañas */}
      <div className="flex bg-black/30 border-b border-white/5 z-10">
        <button onClick={() => setView(View.Chat)} className={`flex-1 py-5 text-[10px] font-black uppercase tracking-[0.3em] transition-all ${view === View.Chat ? 'opacity-100' : 'opacity-20'}`} style={{ color: view === View.Chat ? themeData.primary : 'white' }}>Chat</button>
        <button onClick={() => setView(View.Gallery)} className={`flex-1 py-5 text-[10px] font-black uppercase tracking-[0.3em] transition-all ${view === View.Gallery ? 'opacity-100' : 'opacity-20'}`} style={{ color: view === View.Gallery ? themeData.primary : 'white' }}>Bóveda</button>
      </div>

      {/* Contenido Principal */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {view === View.Chat ? (
          <div ref={scrollRef} className="space-y-5 pb-10">
            {messages.length === 0 && (
              <div className="text-center py-20 space-y-4 opacity-20">
                <span className="text-6xl block">💌</span>
                <p className="text-xs font-black uppercase tracking-widest">No hay secretos aún</p>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                <div 
                  className={`max-w-[80%] px-5 py-3.5 rounded-[1.5rem] shadow-xl relative group ${m.sender === 'me' ? 'rounded-tr-none' : 'rounded-tl-none border border-white/10'}`}
                  style={{ backgroundColor: m.sender === 'me' ? themeData.bubbleMe : themeData.header }}
                  onDoubleClick={() => { if(window.confirm("¿Eliminar este mensaje?")) onDeleteMessage(m.id) }}
                >
                  {m.type === 'image' ? (
                    <div className="relative min-w-[150px]">
                      {m.isSelfDestruct && !m.isOpened ? (
                        <button 
                          onClick={() => { setSelectedImage(m.imageUrl || null); onMarkImageAsOpened(m.id); }}
                          className="flex flex-col items-center justify-center p-8 bg-black/40 rounded-xl border-2 border-dashed border-white/10 w-full"
                        >
                          <span className="text-3xl mb-2">🔥</span>
                          <span className="text-[8px] font-black uppercase tracking-widest">Ver una vez</span>
                        </button>
                      ) : m.isSelfDestruct && m.isOpened ? (
                        <div className="py-4 text-[9px] font-black opacity-30 uppercase italic text-center">Destruido</div>
                      ) : (
                        <img src={m.imageUrl} onClick={() => setSelectedImage(m.imageUrl || null)} className="max-h-[300px] w-full object-cover rounded-xl cursor-zoom-in" />
                      )}
                    </div>
                  ) : (
                    <p className="text-[15px] leading-relaxed break-words">{m.text}</p>
                  )}
                  <div className="flex items-center justify-end mt-1.5 opacity-30 space-x-1.5">
                    <span className="text-[8px] font-bold">{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {m.sender === 'me' && <span className="text-[10px]">{m.status === 'read' ? '✓✓' : '✓'}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3 pb-10">
            {messages.filter(m => m.type === 'image' && !m.isSelfDestruct).map(img => (
              <div key={img.id} className="aspect-square relative overflow-hidden rounded-2xl bg-black/40 border border-white/5">
                <img src={img.imageUrl} onClick={() => setSelectedImage(img.imageUrl || null)} className="w-full h-full object-cover active:scale-95 transition-all" />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Barra de entrada */}
      {view === View.Chat && (
        <footer className="p-4 bg-black/60 backdrop-blur-xl border-t border-white/5 flex items-center space-x-3 pb-10">
          <button onClick={() => fileInputRef.current?.click()} className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform" style={{ backgroundColor: themeData.primary }}>📷</button>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e)} />
          
          <div className="flex-1 bg-white/5 rounded-2xl px-5 py-3.5 border border-white/10 shadow-inner">
            <input 
              type="text" 
              placeholder="Escribe un secreto..." 
              className="w-full bg-transparent text-sm outline-none placeholder:text-white/20"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
          </div>

          <button onClick={handleSend} disabled={!inputText.trim()} className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform disabled:opacity-20" style={{ backgroundColor: themeData.primary }}>🏹</button>
        </footer>
      )}

      {/* MODAL CONFIGURACIÓN COMPLETA */}
      {showSettings && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl p-6 flex items-center justify-center animate-in fade-in zoom-in">
          <div className="w-full max-w-md bg-white/5 rounded-[3rem] p-8 border border-white/10 space-y-8 overflow-y-auto max-h-[90vh] no-scrollbar">
            <div className="text-center space-y-2">
              <h3 className="font-['Dancing+Script'] text-5xl text-white">settings</h3>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] opacity-40">Personaliza vuestro rincón</p>
            </div>

            {/* Perfil del Usuario */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-purple-400">Tu Perfil</h4>
              <div className="flex items-center space-x-5 bg-white/5 p-4 rounded-3xl">
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-purple-500/30 bg-gray-900 cursor-pointer" onClick={() => userAvatarInputRef.current?.click()}>
                   {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center opacity-20">👤</div>}
                </div>
                <input type="file" ref={userAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, false, true)} />
                <div className="flex-1">
                  <input 
                    type="text" 
                    className="bg-transparent border-b border-white/10 w-full font-bold text-sm py-1 outline-none focus:border-purple-500"
                    placeholder="Tu nombre"
                    value={user.name}
                    onChange={(e) => onUpdateUser({ name: e.target.value })}
                  />
                  <p className="text-[9px] opacity-40 mt-1 uppercase">NIP: {user.nip}</p>
                </div>
              </div>
            </section>

            {/* Gestión de Party */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-green-400">Pareja & Party</h4>
              <div className="bg-white/5 p-6 rounded-[2.5rem] space-y-6">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase opacity-40 block">Party ID (Comparte este código)</label>
                  <div className="flex space-x-2">
                    <input 
                      type="text" 
                      className="flex-1 bg-black/40 rounded-xl px-4 py-3 text-sm font-mono outline-none border border-white/5 focus:border-green-500"
                      placeholder="Ej: AMOR2024"
                      value={user.partyId || ''}
                      onChange={(e) => onUpdateUser({ partyId: e.target.value.toUpperCase() })}
                    />
                    {user.partyId && (
                      <button onClick={() => onUpdateUser({ partyId: undefined, partnerName: undefined, partnerAvatar: undefined })} className="bg-red-500/20 text-red-500 px-4 rounded-xl text-xs font-black">SALIR</button>
                    )}
                  </div>
                </div>

                {user.partyId && (
                  <div className="pt-4 border-t border-white/5 space-y-4">
                    <p className="text-[9px] font-black uppercase opacity-40">Detalles de tu Novia</p>
                    <div className="flex items-center space-x-4">
                      <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-green-500/30 bg-gray-900 cursor-pointer" onClick={() => partnerAvatarInputRef.current?.click()}>
                        {user.partnerAvatar ? <img src={user.partnerAvatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center opacity-20">❤</div>}
                      </div>
                      <input type="file" ref={partnerAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, true)} />
                      <input 
                        type="text" 
                        className="flex-1 bg-black/40 rounded-xl px-4 py-3 text-sm font-bold outline-none border border-white/5"
                        placeholder="Nombre de ella"
                        value={user.partnerName || ''}
                        onChange={(e) => onUpdateUser({ partnerName: e.target.value })}
                      />
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Acciones de Datos */}
            <section className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => {
                  const blob = new Blob([JSON.stringify(messages)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `chat_backup_${Date.now()}.json`;
                  a.click();
                }}
                className="bg-white/5 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10"
              >
                Exportar
              </button>
              <button 
                onClick={() => {
                  if(window.confirm("¿Borrar todo permanentemente?")) onClearAll();
                }}
                className="bg-red-500/10 text-red-500 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500/20"
              >
                Borrar Todo
              </button>
            </section>

            <button onClick={() => setShowSettings(false)} className="w-full py-5 text-xs font-black uppercase opacity-30 hover:opacity-100 transition-opacity">Cerrar</button>
          </div>
        </div>
      )}

      {/* Selector de Temas */}
      {showThemeSelector && (
        <div className="fixed inset-0 z-[400] bg-black/98 backdrop-blur-3xl flex items-center justify-center p-8 animate-in fade-in zoom-in duration-300">
          <div className="w-full max-w-sm bg-gray-900/50 rounded-[4rem] p-10 border border-white/10 space-y-10">
            <h3 className="text-center font-['Dancing+Script'] text-6xl text-white">themes</h3>
            <div className="grid grid-cols-2 gap-5">
              {Object.entries(THEMES).map(([key, t]) => (
                <button 
                  key={key} 
                  onClick={() => { onUpdateUser({ theme: key }); setShowThemeSelector(false); }}
                  className={`group relative p-6 rounded-[2.5rem] border-4 transition-all overflow-hidden ${activeTheme === key ? 'border-white scale-105' : 'border-transparent opacity-40'}`}
                  style={{ backgroundColor: t.bg }}
                >
                  <div className="w-10 h-10 rounded-full mb-3 mx-auto shadow-lg" style={{ backgroundColor: t.primary }}></div>
                  <span className="text-[10px] font-black uppercase tracking-widest block text-center leading-none">{t.name}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowThemeSelector(false)} className="w-full text-[10px] font-black uppercase opacity-20 tracking-[0.5em] py-4">Volver</button>
          </div>
        </div>
      )}

      {/* Visor de Imagen Full */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/95 z-[500] flex items-center justify-center p-4 backdrop-blur-xl animate-in fade-in" onClick={() => setSelectedImage(null)}>
          <img src={selectedImage} className="max-w-full max-h-[95vh] object-contain rounded-3xl shadow-2xl animate-in zoom-in duration-300" />
          <button className="absolute top-8 right-8 text-5xl text-white/30 hover:text-white transition-all">×</button>
        </div>
      )}
    </div>
  );
};

export default PrivateSpace;
