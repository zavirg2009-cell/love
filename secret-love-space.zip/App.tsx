
import React, { useState, useEffect } from 'react';
import DecoyView from './components/DecoyView';
import AuthView from './components/AuthView';
import PrivateSpace from './components/PrivateSpace';
import { Message, User, AppStep } from './types';

const SECRET_PIN = '7112024';
const STORAGE_KEYS = {
  ACCOUNTS: '_app_manifest_metadata',
  MESSAGES_PREFIX: '_sys_resource_bundle_',
};

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.Decoy);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  // Cargar mensajes al cambiar de usuario o Party
  useEffect(() => {
    if (currentUser) {
      const storageKey = currentUser.partyId 
        ? `${STORAGE_KEYS.MESSAGES_PREFIX}party_${currentUser.partyId}` 
        : `${STORAGE_KEYS.MESSAGES_PREFIX}user_${currentUser.nip}`;
      
      const saved = localStorage.getItem(storageKey);
      if (saved) setMessages(JSON.parse(saved));
      else setMessages([]);
    }
  }, [currentUser?.partyId, currentUser?.nip]);

  // Guardar mensajes automáticamente
  useEffect(() => {
    if (currentUser) {
      const storageKey = currentUser.partyId 
        ? `${STORAGE_KEYS.MESSAGES_PREFIX}party_${currentUser.partyId}` 
        : `${STORAGE_KEYS.MESSAGES_PREFIX}user_${currentUser.nip}`;
      localStorage.setItem(storageKey, JSON.stringify(messages));
    }
  }, [messages, currentUser]);

  const handleSecretCode = (code: string) => {
    if (code === SECRET_PIN) setStep(AppStep.Auth);
  };

  const handleRegister = (newUser: User) => {
    const usersRaw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    const users: User[] = usersRaw ? JSON.parse(usersRaw) : [];
    
    if (users.some(u => u.nip === newUser.nip)) {
      alert("NIP en uso. Intenta con otro.");
      return;
    }

    const updatedUsers = [...users, newUser];
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedUsers));
    setCurrentUser(newUser);
    setStep(AppStep.Chat);
  };

  const handleLogin = (nip: string) => {
    const usersRaw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    const users: User[] = usersRaw ? JSON.parse(usersRaw) : [];
    const user = users.find(u => u.nip === nip);

    if (user) {
      setCurrentUser(user);
      setStep(AppStep.Chat);
    } else {
      alert("Acceso denegado. Verifica tus credenciales.");
    }
  };

  const updateUserInfo = (updates: Partial<User>) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updates };
      setCurrentUser(updatedUser);
      
      const usersRaw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
      const users: User[] = usersRaw ? JSON.parse(usersRaw) : [];
      const updatedUsers = users.map(u => u.nip === currentUser.nip ? updatedUser : u);
      localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedUsers));
    }
  };

  const addMessage = (msg: Omit<Message, 'id' | 'timestamp' | 'status'>) => {
    const newMessage: Message = {
      ...msg,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      status: 'sent',
    };
    setMessages(prev => [...prev, newMessage]);

    // Simular que el partner lee el mensaje
    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === newMessage.id ? { ...m, status: 'read' as const } : m));
    }, 3000);
  };

  const logout = () => {
    setCurrentUser(null);
    setStep(AppStep.Decoy);
  };

  return (
    <div className="min-h-screen bg-black">
      {step === AppStep.Decoy && <DecoyView onUnlock={handleSecretCode} />}
      {step === AppStep.Auth && (
        <AuthView 
          onLogin={handleLogin} 
          onRegister={handleRegister} 
          onBack={() => setStep(AppStep.Decoy)} 
        />
      )}
      {step === AppStep.Chat && currentUser && (
        <PrivateSpace 
          messages={messages} 
          user={currentUser}
          onSendMessage={addMessage} 
          onDeleteMessage={(id) => setMessages(prev => prev.filter(m => m.id !== id))}
          onMarkImageAsOpened={(id) => {
            setMessages(prev => prev.map(m => (m.id === id && m.isSelfDestruct) ? { ...m, isOpened: true } : m));
            setTimeout(() => setMessages(prev => prev.filter(m => !(m.id === id && m.isSelfDestruct))), 5000);
          }}
          onClearAll={() => setMessages([])}
          onImportData={(data) => setMessages(JSON.parse(data))}
          onLock={logout}
          onUpdateUser={updateUserInfo}
        />
      )}
    </div>
  );
};

export default App;
