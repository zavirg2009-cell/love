
export interface Message {
  id: string;
  sender: 'me' | 'partner';
  text: string;
  timestamp: number;
  type: 'text' | 'image';
  imageUrl?: string;
  status: 'sent' | 'delivered' | 'read';
  isSelfDestruct?: boolean;
  isOpened?: boolean;
}

export interface User {
  nip: string;
  name: string;
  avatar?: string;
  partyId?: string;
  partnerName?: string;
  partnerAvatar?: string;
  theme?: string;
}

export enum AppStep {
  Decoy = 'DECOY',
  Auth = 'AUTH',
  Chat = 'CHAT'
}

export enum View {
  Chat = 'CHAT',
  Gallery = 'GALLERY'
}

export const THEMES = {
  guts: {
    id: 'guts',
    name: 'GUTS Purple',
    primary: '#6b21a8', 
    bg: '#0b141a',
    bubbleMe: '#4c1d95',
    header: '#1e1b4b'
  },
  sour: {
    id: 'sour',
    name: 'SOUR Pink',
    primary: '#db2777',
    bg: '#1a0b14',
    bubbleMe: '#9d174d',
    header: '#2d1a24'
  },
  vampire: {
    id: 'vampire',
    name: 'Vampire Red',
    primary: '#991b1b',
    bg: '#0f0505',
    bubbleMe: '#7f1d1d',
    header: '#1a0a0a'
  },
  obsessed: {
    id: 'obsessed',
    name: 'Obsessed Teal',
    primary: '#0d9488',
    bg: '#050f0f',
    bubbleMe: '#134e4a',
    header: '#0a1a1a'
  }
};
